using System.Linq;
using DG.Tweening;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Magistrate : MonoBehaviour
{
    public static Magistrate Instance;

    [SerializeField] private EnemiesComponent _enemiesComponent;

    [HideInInspector] public Tower _selectedTower;

    [SerializeField] private GameObject _upgradeWindow;
    [SerializeField] private GameObject _buyWindow;

    [SerializeField] private Image _buyCurrentImage, _buyNextImage;
    [SerializeField] private Text _price;

    [SerializeField] private GameObject _coinPrefab;
    [SerializeField] private GameObject _coinCounter;
    [SerializeField] private GameObject _pauseWindow;
    [SerializeField] private Text _coinText;
    [SerializeField] private Text _heartsText;
    [SerializeField] private Text _wavesText;
    [SerializeField] private Text _timeScale;

    [SerializeField] private Button _buyUpgradeButton;
    [SerializeField] private Button _buyButton_Archer, _buyButton_Artillery, _buyButton_Magic;

    [SerializeField] private Animation _fail;

    private int _coins = 1000;
    private int _hearts = 15;
    private int _wave = 1;

    private void Awake()
    {
        Instance = this;
    }

    private void OnEnable()
    {
        UpdateUI();
    }

    public void SelectTower(Tower selectedTower)
    {
        if (selectedTower.Level == 4)
            return;

        _selectedTower = selectedTower;
        _buyWindow.SetActive(false);
        _upgradeWindow.SetActive(false);

        if (selectedTower.Initialized)
        {
            _upgradeWindow.SetActive(true);
            UpdateUpgradeWindow();
        }
        else
        {
            _buyWindow.SetActive(true);
            UpdateBuyWindow();
        }
    }

    public void CrossFinish()
    {
        _fail.Play();

        _hearts--;

        if (_hearts <= 0)
        {
            FinishGame(false);
        }

        UpdateUI();
    }

    public void GoHome()
    {
        SceneManager.LoadScene(0);
    }

    public void Reload()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void Unpause()
    {
        _pauseWindow.SetActive(false);
        Time.timeScale = 1;

        UpdateUI();
    }

    public void Pause()
    {
        _pauseWindow.SetActive(true);
        Time.timeScale = 0;
    }

    public GameObject _finishWindow;
    public Text _finishTitle;

    private void FinishGame(bool victory)
    {
        FindObjectsOfType<Enemy>().ToList().ForEach(x => x.Kill());

        _finishWindow.SetActive(true);

        if (victory)
        {
            _finishTitle.text = $"LEVEL PASSED!";
        }
        else
        {
            _finishTitle.text = $"LEVEL FAILED!";
        }
    }

    public void KillEnemy(Enemy enemy)
    {
        _enemiesComponent._enemiesTemp.Remove(enemy);
        Destroy(enemy.gameObject);
        CheckFinish();
    }

    public void AddCoin(Transform startPoint)
    {
        GameObject coin = Instantiate(_coinPrefab, startPoint);
        coin.transform.parent = _coinCounter.transform;
        coin.transform.DOLocalMove(Vector2.zero, 0.1f).OnComplete(() =>
        {
            _coins += _wave * 25;
            coin.transform.DOScale(0, 0.1f).OnComplete(() => Destroy(coin));
            UpdateUI();
        });
    }

    public void LoadMenu()
    {
        SceneManager.LoadScene(0);
    }

    public void CheckFinish()
    {
        if (_enemiesComponent._enemiesTemp.Count == 0)
        {
            if (_wave == 10)
            {
                FinishGame(true);
                return;
            }

            _wave++;
            _enemiesComponent.NextWave(_wave);

            UpdateUI();
        }
    }

    public void UpdateTimeScale()
    {
        if (Time.timeScale > 3)
            Time.timeScale = 1;
        else
            Time.timeScale++;

        UpdateUI();
    }

    public void UpdateUI()
    {
        _coinText.text = $"{_coins}";
        _heartsText.text = $"{_hearts}/15";
        _wavesText.text = $"WAVE {_wave}/10";
        _timeScale.text = $"x{Time.timeScale}";
    }

    public void BuyTower(int type)
    {
        _coins -= type == 1 ? 100 : type == 2 ? 250 : 500;

        _buyWindow.SetActive(false);
        _selectedTower.Initialize(type);
        SelectTower(_selectedTower);

        UpdateUI();
    }

    public void UpgradeTower()
    {
        if (!_selectedTower.Initialized)
            return;

        int price = (_selectedTower.Level + 1) * _selectedTower.Type * 100;
        _coins -= price;

        _selectedTower.Upgrade();

        if (_selectedTower.Level == 4)
        {
            _upgradeWindow.SetActive(false);
        }
        else
        {
            UpdateUpgradeWindow();
        }

        UpdateUI();
    }

    private void UpdateBuyWindow()
    {
        _buyButton_Archer.interactable = _coins >= 100;
        _buyButton_Artillery.interactable = _coins >= 250;
        _buyButton_Magic.interactable = _coins >= 500;
    }

    private void UpdateUpgradeWindow()
    {
        _buyCurrentImage.sprite = _selectedTower.CurrentSprite;
        _buyNextImage.sprite = _selectedTower.NextSprite;
        _buyNextImage.SetNativeSize();
        _buyCurrentImage.SetNativeSize();
        int price = (_selectedTower.Level + 1) * _selectedTower.Type * 100;
        _price.text = $"{price}";

        _buyUpgradeButton.interactable = _coins >= price;
    }
}