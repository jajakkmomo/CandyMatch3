using UnityEngine;
using DG.Tweening;
using UnityEngine.UI;
using System.Collections.Generic;

public class Enemy : MonoBehaviour
{
    [SerializeField] private Image _enemyImage;
    [SerializeField] private List<Sprite> _enemySprites;
    private float _health = 1f;
    private bool _killed => _health <= 0;

    private void OnEnable()
    {
        _enemyImage.sprite = _enemySprites[Random.Range(0, _enemySprites.Count)];
        _enemyImage.SetNativeSize();
    }

    public void ApplyDamage(float damage)
    {
        if (_killed)
            return;

        _health -= damage;

        _enemyImage.DOKill();
        _enemyImage.DOColor(Color.red, 0.1f).OnComplete(() => _enemyImage.DOColor(Color.white, 0.1f));

        if (_health <= 0)
        {
            Magistrate.Instance.AddCoin(transform);
            Kill();
        }
        else
        {
            UpdateUI();
        }
    }

    public void Kill()
    {
        _enemyImage.DOKill();
        _enemyImage.DOColor(new Color(1, 1, 1, 0), 0.25f).OnComplete(() =>
        {
            Magistrate.Instance.KillEnemy(this);
        });
    }

    private void UpdateUI()
    {

    }

    public void Move(PathComponent pathComponent, int wave)
    {
        if (pathComponent == null || pathComponent.PathPoints == null || pathComponent.PathPoints.Count == 0)
        {
            Debug.LogError("PathComponent or PathPoints is invalid!");
            return;
        }

        int speed = 60;

        switch (wave)
        {
            case 1:
                speed = 90;
                _health = 1;
                break;
            case 2:
                speed = 75;
                _health = 1.1f;
                break;
            case 3:
                speed = 60;
                _health = 1.125f;
                break;
            case 4:
                speed = 55;
                _health = 1.25f;
                break;
            case 5:
                speed = 52;
                _health = 1.33f;
                break;
            case 6:
                speed = 51;
                _health = 1.435f;
                break;
            case 7:
                speed = 50;
                _health = 1.499f;
                break;
            case 8:
                speed = 47;
                _health = 1.565f;
                break;
            case 9:
                speed = 43;
                _health = 1.75f;
                break;
            case 10:
                speed = 40;
                _health = 1.95f;
                break;
            default:
                speed = 60;
                _health = 1;
                break;
        }

        Vector3[] pathPoints = new Vector3[pathComponent.PathPoints.Count];
        for (int i = 0; i < pathComponent.PathPoints.Count; i++)
        {
            pathPoints[i] = pathComponent.PathPoints[i].position;
        }

        transform.DOPath(pathPoints, speed, PathType.Linear)
            .SetEase(Ease.Linear).OnComplete(() =>
            {
                Magistrate.Instance.CrossFinish();
                Kill();
            });
    }
}
