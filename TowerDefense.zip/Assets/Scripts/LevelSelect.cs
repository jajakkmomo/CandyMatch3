using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelSelect : MonoBehaviour
{
    [SerializeField] private int _level;
    [SerializeField] private Text _text;
    [SerializeField] private GameObject _active, _neactive;
    [SerializeField] private List<GameObject> _stars;

    void Awake()
    {
        PlayerPrefs.SetInt("LevelActive1", 1);
    }

    void OnEnable()
    {
        if (PlayerPrefs.GetInt($"LevelActive{_level}", 0) == 1)
        {
            _active.SetActive(true);
            _neactive.SetActive(false);

            _stars.ForEach(x => x.SetActive(false));

            if (PlayerPrefs.GetInt($"LevelCompleted{_level}", 0) == 1)
            {
                int count = PlayerPrefs.GetInt($"LevelStars{_level}", 0);

                for (int i = 0; i < count; i++)
                {
                    _stars[i].SetActive(true);
                }
            }
        }
        else
        {
            _active.SetActive(false);
            _neactive.SetActive(true);
        }
    }

    public void LoadLevel()
    {
        if (PlayerPrefs.GetInt($"LevelActive{_level}", 0) == 1)
        {
            SceneManager.LoadScene(_level);
        }
    }
}
