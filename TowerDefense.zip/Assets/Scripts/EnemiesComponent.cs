using System.Collections.Generic;
using UnityEngine;

public class EnemiesComponent : MonoBehaviour
{
    public PathComponent PathComponent;

    [SerializeField] private Enemy _enemyPrefab;

    public List<Enemy> _enemiesTemp = new();

    private float _defaultSpawnDelay = 3f;
    private float _spawnDelay;

    private int _spawnCount = 25;

    private int _wave = 1;

    public void NextWave(int wave)
    {
        _wave = wave;

        _spawnCount = wave * 10;
    }

    public void Spawn()
    {
        Enemy enemy = Instantiate(_enemyPrefab, PathComponent.transform);
        enemy.transform.position = PathComponent.PathPoints[0].transform.position;
        enemy.Move(PathComponent, _wave);
        _enemiesTemp.Add(enemy);
    }

    public void Update()
    {
        if (Magistrate.Instance._finishWindow.activeSelf)
            return;

        if (_spawnCount <= 0)
            return;

        _spawnDelay += Time.deltaTime;

        if (_spawnDelay >= _defaultSpawnDelay)
        {
            _spawnCount--;
            _spawnDelay = 0;
            Spawn();
        }
    }
}
