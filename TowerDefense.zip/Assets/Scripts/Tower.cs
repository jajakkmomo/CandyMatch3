using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Tower : MonoBehaviour
{
    [SerializeField] private Image _towerImage;
    [SerializeField] private List<Sprite> _towerSprites_Archer;
    [SerializeField] private List<Sprite> _towerSprites_Artillery;
    [SerializeField] private List<Sprite> _towerSprites_Magic;
    [SerializeField] private Projectile _projectilePrefab;
    [SerializeField] private CircleCollider2D _circleCollider;
    [SerializeField] private Image _radius;

    private Enemy _target;

    private int _level = 0;
    private float _attackDelay = 0f;
    private float _defaultAttackDelay = 0.1f;

    private int _type = 0;

    public bool Initialized => _type >= 1;

    public int Type => _type;
    public int Level => _level;

    public Sprite NextSprite
    {
        get
        {
            int nextLevel = _level + 1;

            switch (_type)
            {
                case 1:
                    return _towerSprites_Archer[nextLevel];
                case 2:
                    return _towerSprites_Artillery[nextLevel];
                case 3:
                    return _towerSprites_Magic[nextLevel];
            }

            return _towerImage.sprite;
        }
    }

    public Sprite CurrentSprite => _towerImage.sprite;

    private void UpdateUI()
    {
        switch (_type)
        {
            case 1:
                _towerImage.sprite = _towerSprites_Archer[_level];
                break;
            case 2:
                _towerImage.sprite = _towerSprites_Artillery[_level];
                break;
            case 3:
                _towerImage.sprite = _towerSprites_Magic[_level];
                break;
        }

        _towerImage.SetNativeSize();

        _defaultAttackDelay = 5 / (_level + 1);

        _circleCollider.radius = 150 + 30 * _level;
        _radius.rectTransform.sizeDelta = new Vector2(_circleCollider.radius * 2, _circleCollider.radius * 2);
    }

    public void OnClick()
    {
        Magistrate.Instance.SelectTower(this);
    }

    public void Initialize(int type)
    {
        _type = type;

        _radius.gameObject.SetActive(true);

        _towerImage.enabled = true;

        UpdateUI();
    }

    public void Upgrade()
    {
        _level++;

        UpdateUI();
    }

    private void Attack()
    {
        if (_target != null)
        {
            Projectile projectile = Instantiate(_projectilePrefab, transform);
            projectile.MoveTo(_target, _level, _type);
        }
    }

    private void SetTarget(Enemy enemy)
    {
        _target = enemy;
    }

    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.TryGetComponent(out Enemy enemy))
        {
            SetTarget(enemy);
        }
        else
        {
            SetTarget(null);
        }
    }

    public void OnTriggerStay2D(Collider2D other)
    {
        if (other.TryGetComponent(out Enemy enemy))
        {
            SetTarget(enemy);
        }
        else
        {
            SetTarget(null);
        }
    }

    public void OnTriggerExit2D(Collider2D other)
    {
        if (other.TryGetComponent(out Enemy enemy))
        {
            if (enemy == _target)
                SetTarget(null);
        }
    }

    public void Update()
    {
        if (!Initialized)
            return;

        _attackDelay += Time.deltaTime;

        if (_attackDelay > _defaultAttackDelay)
        {
            _attackDelay = 0;
            Attack();
        }
    }
}