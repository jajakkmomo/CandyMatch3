using DG.Tweening;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    private Enemy _target;

    private float _speed;
    private float _damage;

    public void MoveTo(Enemy target, int preset, int type = 1)
    {
        switch (preset + 1)
        {
            case 1:
                _speed = 1f;
                _damage = 0.1f * type;
                break;
            case 2:
                _speed = 0.9f;
                _damage = 0.2f * type;
                break;
            case 3:
                _speed = 0.825f;
                _damage = 0.3f * type;
                break;
            case 4:
                _speed = 0.75f;
                _damage = 0.4f * type;
                break;
            case 5:
                _speed = 0.5f;
                _damage = 0.51f * type;
                break;
        }

        _target = target;
        transform.parent = target.transform;
        transform.DOLocalMove(Vector2.zero, _speed).SetEase(Ease.Linear).OnComplete(() =>
        {
            if (target != null)
                target.ApplyDamage(_damage);

            transform.DOScale(0, 0.1f).OnComplete(() => Destroy(this.gameObject));
        });
    }

    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.TryGetComponent(out Enemy enemy))
        {
            if (enemy == _target)
            {
                enemy.ApplyDamage(_damage);
                Destroy(this.gameObject);
            }
        }
    }
}
