using System.Collections.Generic;
using UnityEngine;

public class PathComponent : MonoBehaviour
{
    public List<Transform> PathPoints;
}
